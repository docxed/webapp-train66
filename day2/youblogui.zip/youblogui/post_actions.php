<?php
include './db.php'; // เรียกใช้ไฟล์ db.php
if (isset($_POST['create'])) { // สร้างโพสต์
    /*
        Code here
    */
} else if (isset($_POST['update'])) { // แก้ไขโพสต์
    /*
        Code here
    */
} else if (isset($_GET['delete'])) { // ลบโพสต์
    /*
        Code here
    */
}
